// src/contexts/ThemeContext.tsx
import React, { createContext, useContext, useState, useEffect } from 'react';

interface ThemeContextValue {
  darkMode: boolean;
  toggleDarkMode: () => void;        // 🔑 renombrado
}

const ThemeContext = createContext<ThemeContextValue>(null!);

export const ThemeProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const stored = localStorage.getItem('darkMode');
    return stored ? JSON.parse(stored) : true;
  });

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    document.documentElement.classList[darkMode ? 'add' : 'remove']('dark');
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(prev => !prev); // 🔑 renombrado

  return (
    <ThemeContext.Provider value={{ darkMode, toggleDarkMode }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
