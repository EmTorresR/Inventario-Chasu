// Home.tsx
function Home() {
    return <h1>Bienvenido a Inventario-Chasu</h1>;
  }
  
  export default Home;
  