// About.tsx
function About() {
    return <h1>Acerca de Inventario-Chasu</h1>;
  }
  
  export default About;
  